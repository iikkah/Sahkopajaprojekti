#ifndef COMMLIB_H
#define COMMLIB_H

#include <Arduino.h>

//Messages the machine can receive
typedef enum {
    R_NOP,        //No operation / message received
    R_COMM_ERR,   //Communication error (sent by the host in case it receives corrupted data)
    R_REQ_SPEC,   //Request specification
    R_REQ_ID,     //Request ID
    R_CAL,        //Calibrate
    R_RES,        //Reset
    R_RSTK,       //Restock
    R_SRV_C,      //Serve can
    R_ADD_C,      //Add can
    R_SND_STAT,   //Sending status
	INT_COMM_ERR, //Communication error (internal, used to forward information about corrupted received data)
    R_HLT = 0xFF  //Halt / finished
} rcv;

//Messages the machine can send
typedef enum {
    S_NOP,        //No operation / message received
    S_COMM_ERR,   //Communication error (request repeat)
    S_NA,         //Function not available
    S_SND_SPEC,   //Sending specification
    S_SND_ID,     //Sending ID
    S_C_GET,      //Can taken from shelf
    S_C_OPEN,     //Can opened
	S_C_EJECT,    //Can ejected
    S_REQ_STAT,   //Request status (needed for calibrate on some machines)
    S_ERR = 0xFE, //Hardware error
    S_HLT = 0xFF  //Halt / finished
} snd;

//Actions the machine can take (hardware manipulation)
typedef enum {
    NOA,    //No action
    CAL,    //Calibrate
    RES,    //Reset
    RSTK,   //Restock
    SRV_C,  //Serve can
    ADD_C,   //Add can
} act;

act commListen(byte *info);

void sendStatGet();
void sendStatOpen();
void sendStatEject();
void sendDone();

#endif
