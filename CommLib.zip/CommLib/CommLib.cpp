#include <CommLib.h>

byte checkParity(byte Byte){
  byte parity = 0;
  for(byte i = 0; i < 8; i++){
    if(Byte & (1 << i)) parity = !parity;
  }
  return parity;
}

rcv parseReceived(byte check, byte *bytes, byte *info){
  byte n = check & 0x07;
  for(byte i = 0; i < n; i++){
	if((bool) checkParity(bytes[i]) != (bool) (check & (1 << (i+3)))){
      return INT_COMM_ERR;
    }
  }
  memcpy(info, bytes + 1, n - 1);
  return (rcv) bytes[0];
}

void sendMessage(snd cmd, byte *info, byte n){
  byte check = n;
  check += checkParity(cmd) << 3;
  for(byte i = 0; i < (n - 1); i++){
    check += checkParity(info[i]) << 3;
  }
  byte *msg = calloc(info, n + 1);
  memcpy(msg + 2, info, n - 1);
  *msg = check;
  *(msg + 1) = cmd;
  Serial.write(msg, n + 1);
  free(msg);
}

void sendStatGet(){ sendMessage(S_C_GET, {}, 1);}

void sendStatOpen(){ sendMessage(S_C_OPEN, {}, 1);}

void sendStatEject(){ sendMessage(S_C_EJECT, {}, 1);}

void sendDone(){ sendMessage(S_HLT, {}, 1);}

act commListen(byte *info){
  if(Serial.available()){
    byte check = Serial.read();
    byte n = check & 0x07;
    while(Serial.available() < n){;}
    byte *bytes = calloc(n, 1);
    Serial.readBytes(bytes, n);
	rcv rec = parseReceived(check, bytes, info);
	free(bytes);
	switch(rec){
      case R_NOP: return NOA;
	  case R_COMM_ERR: return NOA;
	  case R_REQ_SPEC: /*sendSpec();*/ break;
      case R_REQ_ID: /*sendID();*/ break;
      case R_CAL: return CAL;
	  case R_RES: return RES;
      case R_RSTK: return RSTK;
      case R_SRV_C: return SRV_C;
      case R_ADD_C: return ADD_C;
	  case INT_COMM_ERR: sendMessage(S_COMM_ERR, {}, 1); return NOA;
      case R_SND_STAT: /*parseStat();*/ break;
	  case R_HLT: break;
      default: return NOA;
    }
  }
  
  return NOA;
}
